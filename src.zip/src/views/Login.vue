<template>
  <div>login page</div>
</template>

<script setup></script>

<style></style>
